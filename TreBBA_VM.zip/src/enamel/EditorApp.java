package enamel;

import java.io.IOException;

public class EditorApp{

	public static void main(String[] args) throws IOException {
		ScenarioFileEditor y = new ScenarioFileEditor();		//initialize
		y.setVisible(true);
	}

}
